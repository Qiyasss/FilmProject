package com.example.filmwatchproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmWatchProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
