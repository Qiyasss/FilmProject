package com.example.filmwatchproject.enums;

import lombok.Getter;

@Getter
public enum ErrorCodeEnum  {
    UNKNOWN_ERROR(1000, "Unknown error"),
    FILM_NOT_FOUND(1001, "Cannot find film with given id "),
    NOT_ENOUGH_FILM(1002, "FILM not found");
    private final int code;
    private final String message;

    ErrorCodeEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

}
