package com.example.filmwatchproject.dto;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Data
public class FilmEntityDto {


    int id;

    @Column(name = "Name", nullable = false, unique = true)
    String filmName;

    @Column(name = "Director", nullable = false)
    String filmDirector;

    @Column(name = "Scenarist", nullable = false)
    String filmScenarist;

    @Column(name = "Awards", nullable = false)
    int filmAwards;

}
