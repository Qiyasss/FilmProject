package com.example.filmwatchproject.controller;

import com.example.filmwatchproject.dto.FilmEntityDto;
import com.example.filmwatchproject.entity.FilmEntity;
import com.example.filmwatchproject.service.FilmImplements;
import com.example.filmwatchproject.service.FilmInterface;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/begin")
@RequiredArgsConstructor
public class FilmController {

   private final FilmInterface filmInterface;


    @PostMapping("/set")
    public void create(@RequestBody FilmEntityDto filmEntityDto) {
        filmInterface.create(filmEntityDto);
    }

    @DeleteMapping("/delete/{id}" )
   public void delete(@PathVariable int id) {
        filmInterface.delete(id);
    }


    @GetMapping( "/get" )
    public List<FilmEntity> getAllFilms(){
        return filmInterface.getAllFilms();
    }

    @PutMapping("/update/{id}")
    public FilmEntity update(@PathVariable int id, FilmEntityDto filmEntityDto){
      return   filmInterface.update(id, filmEntityDto);
    }

    @GetMapping("/findById/{id}")
    public FilmEntityDto findbyId(@PathVariable int id){
      return   filmInterface.findbyId(id);
    }

}
