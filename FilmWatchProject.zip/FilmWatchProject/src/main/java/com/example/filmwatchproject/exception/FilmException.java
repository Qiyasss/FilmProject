package com.example.filmwatchproject.exception;

import com.example.filmwatchproject.enums.ErrorCodeEnum;
import lombok.Getter;

@Getter
public class FilmException extends RuntimeException {
    private final String message;
    private final int code;


    public FilmException(ErrorCodeEnum errorCodeEnum) {
        super(errorCodeEnum.getMessage());
        this.message = errorCodeEnum.getMessage();
        this.code = errorCodeEnum.getCode();
    }
}
