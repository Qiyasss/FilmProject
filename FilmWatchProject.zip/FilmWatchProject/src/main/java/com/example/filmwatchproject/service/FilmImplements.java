package com.example.filmwatchproject.service;

import com.example.filmwatchproject.dto.FilmEntityDto;
import com.example.filmwatchproject.entity.FilmEntity;
import com.example.filmwatchproject.enums.ErrorCodeEnum;
import com.example.filmwatchproject.exception.FilmException;
import com.example.filmwatchproject.repository.FilmRepository;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class FilmImplements implements FilmInterface{

    private final FilmRepository filmRepository;
    private final ModelMapper modelMapper;

    @Override
    public void create(FilmEntityDto filmEntityDto) {

        FilmEntity filmEntity = FilmEntity.builder().
                id(filmEntityDto.getId()).
                filmName(filmEntityDto.getFilmName()).
                filmDirector(filmEntityDto.getFilmDirector()).
                filmScenarist(filmEntityDto.getFilmScenarist()).
                filmAwards(filmEntityDto.getFilmAwards()).
                build();

        filmRepository.save(filmEntity);
    }

    @Override
    public void delete(int id) {
    filmRepository.deleteById(id);

    }

    @Override
    public List<FilmEntity> getAllFilms() {
    return filmRepository.findAll();

    }

    @Override
    public FilmEntity update(int id, FilmEntityDto filmEntityDto) {

        Optional<FilmEntity> updateFilm = filmRepository.findById(id);
        if (updateFilm.isPresent()) {

            FilmEntity newFilm = updateFilm.get();

            newFilm.setFilmName(filmEntityDto.getFilmName());
            newFilm.setFilmDirector(filmEntityDto.getFilmDirector());
            newFilm.setFilmScenarist(filmEntityDto.getFilmScenarist());
            newFilm.setFilmAwards(filmEntityDto.getFilmAwards());

            return filmRepository.save(newFilm);

        }
        return null;

    }

    @Override
    public FilmEntityDto findbyId(int id) {
        Optional<FilmEntity> filmEntity = filmRepository.findById(id);
        System.out.println(filmEntity.isEmpty());
        if (filmEntity.isEmpty()) {
            throw new FilmException(ErrorCodeEnum.FILM_NOT_FOUND);
        }
    return filmEntity.map(filmE-> modelMapper.map(filmE,FilmEntityDto.class)).orElseThrow();

    }
    }



