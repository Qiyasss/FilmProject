package com.example.filmwatchproject.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table
@Getter
@Setter

public class FilmEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;

    @Column(name = "Name", nullable = false, unique = true)
    String filmName;

    @Column(name = "Director", nullable = false)
    String filmDirector;

    @Column(name = "Scenarist", nullable = false)
    String filmScenarist;

    @Column(name = "Awards", nullable = false)
    int filmAwards;

    }
