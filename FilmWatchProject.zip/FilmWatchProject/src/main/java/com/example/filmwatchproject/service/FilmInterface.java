package com.example.filmwatchproject.service;

import com.example.filmwatchproject.dto.FilmEntityDto;
import com.example.filmwatchproject.entity.FilmEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface FilmInterface {




    void create(FilmEntityDto filmEntityDto);

    void delete(int id);

    List<FilmEntity> getAllFilms();


    FilmEntity update(int id, FilmEntityDto filmEntityDto);



    FilmEntityDto findbyId(int id);
}
